import { Link, useParams } from "react-router-dom";

import {
  ArrowLeft,
  ExternalLink,
} from "lucide-react";

import { FaGithub } from "react-icons/fa";

import { useProjectBySlug } from "../../hooks/useProjects";

const ProjectDetailsPage = () => {
  const { slug } = useParams<{
    slug: string;
  }>();

  const {
    data: project,
    isLoading,
    isError,
  } = useProjectBySlug(slug ?? "");

  if (isLoading) {
    return (
      <main className="min-h-screen bg-white">
        <div className="mx-auto max-w-5xl px-4 py-20 sm:px-6 lg:px-8">
          <div className="h-5 w-32 animate-pulse rounded bg-slate-200" />

          <div className="mt-10 h-12 w-3/4 animate-pulse rounded bg-slate-200" />

          <div className="mt-6 h-24 animate-pulse rounded bg-slate-200" />

          <div className="mt-12 aspect-[16/9] animate-pulse bg-slate-200" />
        </div>
      </main>
    );
  }

  if (isError || !project) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-white px-4">
        <div className="text-center">
          <h1 className="text-3xl font-semibold text-slate-950">
            Project not found
          </h1>

          <p className="mt-4 text-slate-600">
            This project could not be loaded.
          </p>

          <Link
            to="/#projects"
            className="mt-8 inline-flex items-center gap-2 border border-slate-300 px-5 py-3 text-sm font-medium text-slate-950 transition-colors hover:border-slate-950"
          >
            <ArrowLeft size={17} />
            Back to projects
          </Link>
        </div>
      </main>
    );
  }

  const formatDate = (
    date: string | null
  ) => {
    if (!date) {
      return null;
    }

    return new Date(date).toLocaleDateString(
      "en-US",
      {
        month: "long",
        year: "numeric",
      }
    );
  };

  return (
    <main className="min-h-screen bg-white">
      <div className="mx-auto max-w-5xl px-4 py-12 sm:px-6 lg:px-8 lg:py-20">
        <Link
          to="/#projects"
          className="inline-flex items-center gap-2 text-sm font-medium text-slate-600 transition-colors hover:text-slate-950"
        >
          <ArrowLeft size={17} />
          Back to projects
        </Link>

        <div className="mt-10">
          <p className="text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">
            {project.status.replace("_", " ")}
          </p>

          <h1 className="mt-4 text-4xl font-semibold tracking-tight text-slate-950 sm:text-5xl">
            {project.title}
          </h1>

          <p className="mt-6 max-w-3xl text-lg leading-8 text-slate-600">
            {project.full_description}
          </p>

          {(project.start_date ||
            project.end_date) && (
            <p className="mt-5 text-sm text-slate-500">
              {formatDate(project.start_date)}

              {project.start_date &&
                project.end_date &&
                " — "}

              {formatDate(project.end_date)}
            </p>
          )}

          {(project.github_url ||
            project.live_url) && (
            <div className="mt-8 flex flex-wrap gap-4">
              {project.github_url && (
                <a
                  href={project.github_url}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-2 bg-slate-950 px-5 py-3 text-sm font-medium text-white"
                >
                  <FaGithub size={17} />
                  View Source Code
                </a>
              )}

              {project.live_url && (
                <a
                  href={project.live_url}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-2 border border-slate-300 px-5 py-3 text-sm font-medium text-slate-950 transition-colors hover:border-slate-950"
                >
                  <ExternalLink size={17} />
                  View Live Project
                </a>
              )}
            </div>
          )}
        </div>

        {project.thumbnail_url && (
          <div className="mt-12 overflow-hidden border border-slate-200">
            <img
              src={project.thumbnail_url}
              alt={project.title}
              className="h-auto w-full object-cover"
            />
          </div>
        )}

        {project.technologies.length > 0 && (
          <section className="mt-16 border-t border-slate-200 pt-12">
            <h2 className="text-2xl font-semibold text-slate-950">
              Technologies
            </h2>

            <div className="mt-6 flex flex-wrap gap-3">
              {project.technologies.map(
                (technology) => (
                  <span
                    key={technology.id}
                    className="border border-slate-200 px-3 py-2 text-sm text-slate-700"
                  >
                    {technology.name}
                  </span>
                )
              )}
            </div>
          </section>
        )}

        {project.problem && (
          <section className="mt-16 border-t border-slate-200 pt-12">
            <h2 className="text-2xl font-semibold text-slate-950">
              Problem
            </h2>

            <p className="mt-5 whitespace-pre-line leading-8 text-slate-600">
              {project.problem}
            </p>
          </section>
        )}

        {project.solution && (
          <section className="mt-16 border-t border-slate-200 pt-12">
            <h2 className="text-2xl font-semibold text-slate-950">
              Solution
            </h2>

            <p className="mt-5 whitespace-pre-line leading-8 text-slate-600">
              {project.solution}
            </p>
          </section>
        )}

        {project.features &&
          project.features.length > 0 && (
            <section className="mt-16 border-t border-slate-200 pt-12">
              <h2 className="text-2xl font-semibold text-slate-950">
                Key Features
              </h2>

              <ul className="mt-6 grid gap-3 sm:grid-cols-2">
                {project.features.map(
                  (feature, index) => (
                    <li
                      key={`${feature}-${index}`}
                      className="border border-slate-200 p-4 text-slate-700"
                    >
                      {feature}
                    </li>
                  )
                )}
              </ul>
            </section>
          )}

        {project.architecture && (
          <section className="mt-16 border-t border-slate-200 pt-12">
            <h2 className="text-2xl font-semibold text-slate-950">
              Architecture
            </h2>

            <p className="mt-5 whitespace-pre-line leading-8 text-slate-600">
              {project.architecture}
            </p>
          </section>
        )}

        {project.challenges && (
          <section className="mt-16 border-t border-slate-200 pt-12">
            <h2 className="text-2xl font-semibold text-slate-950">
              Challenges
            </h2>

            <p className="mt-5 whitespace-pre-line leading-8 text-slate-600">
              {project.challenges}
            </p>
          </section>
        )}

        {project.results && (
          <section className="mt-16 border-t border-slate-200 pt-12">
            <h2 className="text-2xl font-semibold text-slate-950">
              Results
            </h2>

            <p className="mt-5 whitespace-pre-line leading-8 text-slate-600">
              {project.results}
            </p>
          </section>
        )}

        {project.lessons_learned && (
          <section className="mt-16 border-t border-slate-200 pt-12">
            <h2 className="text-2xl font-semibold text-slate-950">
              Lessons Learned
            </h2>

            <p className="mt-5 whitespace-pre-line leading-8 text-slate-600">
              {project.lessons_learned}
            </p>
          </section>
        )}

        {project.images.length > 0 && (
          <section className="mt-16 border-t border-slate-200 pt-12">
            <h2 className="text-2xl font-semibold text-slate-950">
              Project Gallery
            </h2>

            <div className="mt-8 grid gap-6 sm:grid-cols-2">
              {project.images
                .sort(
                  (a, b) =>
                    a.display_order -
                    b.display_order
                )
                .map((image) => (
                  <figure
                    key={image.id}
                    className="overflow-hidden border border-slate-200"
                  >
                    <img
                      src={image.url}
                      alt={
                        image.alt_text ||
                        project.title
                      }
                      className="h-full w-full object-cover"
                    />

                    {image.alt_text && (
                      <figcaption className="border-t border-slate-200 p-3 text-sm text-slate-500">
                        {image.alt_text}
                      </figcaption>
                    )}
                  </figure>
                ))}
            </div>
          </section>
        )}
      </div>
    </main>
  );
};

export default ProjectDetailsPage;